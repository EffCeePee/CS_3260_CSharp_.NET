﻿
// Project Prologue
// Franklin Colton Parry
// Course: CS 3260
// File: employee_classes.cs
// Date: 2/24/2014

// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace employee
{
    interface IFileAccess
    {
        void writeDB();
        void readDB();
        void openDB();
        void closeDB();
        SortedDictionary<uint, Employee> DB { get; set; }
    }//end interface IFileAccess


    public class FileIO : object, IFileAccess
    {
        //member data as required
        //member properties & indexers as required
        //member methods as required
        private Hourly hrly = new Hourly(10, ETYPE.Hourly, "Micky Mouse", 25.66M, 13.25);
        private Salary salry = new Salary(11, ETYPE.Salary, "Donald Duck", 40000.00M);
        private Sales sles = new Sales(12, ETYPE.Sales, "Princess Ariel", 10000.00M, 1000000.00M, 250000.00M);
        private Contract contrct = new Contract(13, ETYPE.Contract, "Walt Disney", 20000.00M);
        
        
        private FileStream fileStream;
        private BinaryFormatter binaryFormatter;

        public SortedDictionary<uint, Employee> DB { get; set; }

        public FileIO()
        {
            
            fileStream = new FileStream(@"C:\Users\F\Desktop\BinaryFormat.bn", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            
            
        }

        

        void IFileAccess.openDB()
        {
            
                 
        }

         void IFileAccess.closeDB()
        {
            fileStream.Close();
        }

        void IFileAccess.writeDB()
        {

        }

        void IFileAccess.readDB()
        {

        }
        

            //try
            //{
            //}
            //catch (IOException ioexp)
            //{
            //    Console.WriteLine("IOException - {0}", ioexp.Message);

            //}
            //catch(Exception exp)
            //{
            //    Console.WriteLine("Exception - {0}", exp.Message);

            //}
            //finally
            //{
            //    fileStream.Close();
            //    Console.WriteLine("End Binary Formatter");

            
    }   //end class FileIO
}
